package main

import (
	"fmt"
	"log"
	"net/http"
	"os"

	goscript "github.com/davidjeba/goscript/pkg/goscript"
)

func main() {
	port := "8080"
	if p := os.Getenv("PORT"); p != "" {
		port = p
	}

	// Create the App Router
	router := goscript.NewAppRouter("/")

	// Register a simple home page route
	router.RegisterRoute("/", func(w http.ResponseWriter, r *http.Request, params map[string]string) {
		metadata := goscript.NewMetadata().
			SetTitle("GoScript 2.0 — Full-Stack Go Web Framework").
			SetDescription("A Next.js-inspired full-stack web framework written in Go").
			SetCanonical("http://localhost:" + port).
			SetThemeColor("#10b981").
			Build()

		html := fmt.Sprintf(`<!DOCTYPE html>
<html lang="en">
<head>%s</head>
<body>
<div id="__goscript_app">
<h1>GoScript 2.0</h1>
<p>A full-stack Go web framework inspired by Next.js</p>
<ul>
<li>App Router with file-system conventions</li>
<li>Streaming SSR</li>
<li>Server &amp; Client Components</li>
<li>API Routes</li>
<li>Middleware Pipeline</li>
<li>SSG / ISR</li>
<li>Error &amp; Loading Boundaries</li>
<li>Metadata API &amp; SEO</li>
<li>HMR Dev Server</li>
</ul>
</div>
</body>
</html>`, metadata.Render())

		w.Header().Set("Content-Type", "text/html")
		w.Write([]byte(html))
	}, []string{"GET"})

	// Register an API route
	apiRouter := goscript.NewAPIRouter()
	apiRouter.GET("/api/health", func(ctx *goscript.APIContext) (interface{}, error) {
		return map[string]interface{}{
			"status":  "healthy",
			"version": "2.0.0",
		}, nil
	})
	apiRouter.GET("/api/hello", func(ctx *goscript.APIContext) (interface{}, error) {
		name := ctx.Query["name"]
		if name == "" {
			name = "World"
		}
		return map[string]interface{}{
			"message": fmt.Sprintf("Hello, %s!", name),
		}, nil
	})

	// Set up middleware
	router.Use(func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			w.Header().Set("X-Powered-By", "GoScript/2.0")
			next.ServeHTTP(w, r)
		})
	})

	// Create the main mux
	mux := http.NewServeMux()
	mux.Handle("/", router)
	mux.Handle("/api/", apiRouter)

	addr := ":" + port
	fmt.Printf("GoScript 2.0 Server\n")
	fmt.Printf("  Server:  http://localhost:%s\n", port)
	fmt.Printf("  API:     http://localhost:%s/api/health\n", port)
	fmt.Printf("  Press Ctrl+C to stop\n\n")

	if err := http.ListenAndServe(addr, mux); err != nil {
		log.Fatalf("Server error: %v", err)
	}
}
